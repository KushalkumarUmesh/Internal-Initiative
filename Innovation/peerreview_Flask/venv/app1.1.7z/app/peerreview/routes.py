from flask import render_template,request,redirect,url_for
from peerreview import app
from peerreview.forms import *
from peerreview.models import *
from flask_login import login_user,logout_user,current_user,login_required,login_manager

@app.route("/")
@app.route("/home",methods=['GET','POST'])
# @login_required  
def home():
    return render_template('home.html',title='Home')

@app.route("/login",methods=['GET','POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    form = LoginForm()
    if form.validate_on_submit() :
        print('login successful')
        return redirect(url_for('home'))
    else:
        print('please use valid credentials')
    return render_template('Login.html',title='login' ,form = form)

@app.route("/create_new_project",methods=['GET','POST'])
def create_new_project():
    return render_template('create_new_project.html',title='create_new_project') 

@app.route("/edit_existing_project",methods=['GET','POST'])
def edit_existing_project():
    return render_template('edit_existing_project.html') 

@app.route("/update_tracker",methods=['GET','POST'])
def update_tracker():
    return render_template('update_tracker.html')         
