from peerreview import db
from peerreview.models import Login,EmployeeDetails,BusinessInfo,CreateProject,ChecklistDetails,TestingType,UserLevel,UserStatus,Frequency,ReviewTask
import sqlite3



# CREATES ALL THE TABLES Model --> DB TABLE
db.create_all()



###### CREATING LOGIN INFO DATA into the DATABASE Table "PRD_EMPLOYEE_DETAILS" ######
#login_user1 = Login("TEST ADMIN","testadmin@msg-global.com","msgtesting@123")
#login_user2 = Login("TEST MANAGER","testmanager@msg-global.com","msgtesting@123")
#login_user3 = Login("TEST USER","testuser@msg-global.com","msgtesting@123")

#db.session.add_all([login_user1,login_user2,login_user3])
#db.session.commit()

#### To get data from DATABASE Table "PRD_EMPLOYEE_DETAILS" using id(index)
#admin_login = Login.query.get(1)
#print(admin_login.EMP_NAME)
#print('-----------------------------------')

## To get all data in the Table PRD_EMPLOYEE_DETAILS
login_users = Login.query.all()
print(login_users)
print('-----------------------------------')


###### CREATING EMPLOYEE DATA into the DATABASE Table "PRD_EMPLOYEE_DETAILS" ######
emp1 = EmployeeDetails("TEST ADMIN","testadmin@msg-global.com","msgtesting@123",1,1)
emp2 = EmployeeDetails("TEST MANAGER","testmanager@msg-global.com","msgtesting@123",2,1)
emp3 = EmployeeDetails("TEST USER","testuser@msg-global.com","msgtesting@123",3,1)

db.session.add_all([emp1,emp2,emp3])
db.session.commit()

#### To get data from DATABASE Table "PRD_EMPLOYEE_DETAILS" using id(index)
admin_emp = EmployeeDetails.query.get(1)
print(admin_emp.EMP_NAME)
print('-----------------------------------')

## To get all data in the Table PRD_EMPLOYEE_DETAILS
emp_details = EmployeeDetails.query.all()
print(emp_details)
print('-----------------------------------')


###### CREATING USER lEVEL DATA into the DATABASE Table PRD_USER_LEVEL ######
userlevel_1 = UserLevel('ADMIN')
userlevel_2 = UserLevel('MANAGER')
userlevel_3 = UserLevel('USER')
db.session.add_all([userlevel_1,userlevel_2,userlevel_3])
db.session.commit()

#### To get data from DATABASE Table PRD_USER_LEVEL using id(index)
admin = UserLevel.query.get(1)
print(admin.USR_LEVEL)

manager = UserLevel.query.get(2)
print(manager.USR_LEVEL)

user = UserLevel.query.get(3)
print(user.USR_LEVEL)

## To get all data in the Table PRD_USER_LEVEL
all_users = UserLevel.query.all()
print(all_users)
print('-----------------------------------')


###### CREATING USER STATUS DATA into the DATABASE Table PRD_USER_STATUS ######
user_active = UserStatus('ACTIVE')
user_inactive = UserStatus('INACTIVE')
db.session.add_all([user_active,user_inactive])
db.session.commit()

#### To get data from DATABASE Table PRD_USER_STATUS using id(index)
active = UserStatus.query.get(1)
print(active.USR_STATUS)

inactive = UserStatus.query.get(2)
print(inactive.USR_STATUS)

## To get all data in the Table PRD_USER_STATUS
all_status = UserStatus.query.all()
print(all_status)
print('-----------------------------------')



###### CREATING REVIEW TASK DATA into the DATABASE Table PRD_REVIEW_TASK ######
task1 = ReviewTask('CREATE NEW PROJECT')
task2 = ReviewTask('EDIT EXISTING PROJECT')
task3 = ReviewTask('UPDATE TRACKER')
db.session.add_all([task1,task2,task3])
db.session.commit()

#### To get data from DATABASE Table PRD_REVIEW_TASK using id(index)
new_project = ReviewTask.query.get(1)
print(new_project.REVIEW_TASK)

existing_project = ReviewTask.query.get(2)
print(existing_project.REVIEW_TASK)

## To get all data in the Table PRD_REVIEW_TASK
all_tasks = ReviewTask.query.all()
print(all_tasks)
print('-----------------------------------')



###### CREATING FREQUENCY DATA into the DATABASE Table PRD_FREQUENCY ######
frequency1 = Frequency('DAILY')
frequency2 = Frequency('WEEKLY')
frequency3 = Frequency('BI-WEEKLY')
frequency4 = Frequency('MONTHLY')
db.session.add_all([frequency1,frequency2,frequency3,frequency4])
db.session.commit()

#### To get data from DATABASE Table PRD_FREQUENCY using id(index)
daily = Frequency.query.get(1)
print(daily.FREQUENCY_TYPE)

weekly = Frequency.query.get(2)
print(weekly.FREQUENCY_TYPE)

## To get all data in the Table PRD_TESTING_TYPE
all_frequencies = Frequency.query.all()
print(all_frequencies)
print('-----------------------------------')


###### CREATING TESTING TYPE DATA into the DATABASE Table PRD_TESTING_TYPE ######
testType1 = TestingType('MANUAL TESTING')
testType2 = TestingType('AUTOMATION TESTING')
testType3 = TestingType('PERFORMANCE TESTING')
testType4 = TestingType('SECURITY TESTING')
testType5 = TestingType('TEST MANAGEMENT')
db.session.add_all([testType1,testType2,testType3,testType4,testType5])
db.session.commit()

#### To get data from DATABASE Table PRD_TESTING_TYPE using id(index)
manual = TestingType.query.get(1)
print(manual.TESTING_TYPE)

automation = TestingType.query.get(2)
print(automation.TESTING_TYPE)

performance = TestingType.query.get(3)
print(performance.TESTING_TYPE)

## To get all data in the Table PRD_TESTING_TYPE
all_testTypes = TestingType.query.all()
print(all_testTypes)
print('-----------------------------------')



###### CREATING CHECKLISTS DATA into the DATABASE Table PRD_CHECKLIST_DETAILS ######
checklist1 = ChecklistDetails('AUTOMATION CHECKLIST',2)
checklist2 = ChecklistDetails('C# CODING STANDARDS',2)
checklist3 = ChecklistDetails('DEFECT CHECKLIST',1)
checklist4 = ChecklistDetails('JAVA CODING STANDARDS',2)
checklist5 = ChecklistDetails('PYTHON CODING STANDARDS',2)
checklist6 = ChecklistDetails('REQUIREMENT TRACEABILITY CHECKLIST',1)
checklist7 = ChecklistDetails('TEST ENVIRONMENT SETUP CHECKLIST',5)
checklist8 = ChecklistDetails('TEST PLAN CHECKLIST',5)
checklist9 = ChecklistDetails('TEST REPORT CHECKLIST',5)
checklist10 = ChecklistDetails('TESTCASE CHECKLIST',1)
checklist11 = ChecklistDetails('TOSCA CODING STANDARDS',2)
checklist12 = ChecklistDetails('UFT CODING STANDARDS',2)
db.session.add_all([checklist1,checklist2,checklist3,checklist4,checklist5,checklist6,checklist7,checklist8,checklist9,checklist10,checklist11,checklist12])
db.session.commit()

#### To get data from DATABASE Table PRD_CHECKLIST_DETAILS using id(index)
auto_chk = ChecklistDetails.query.get(1)
print(auto_chk.CHECKLIST_NAME)

defect_chk = ChecklistDetails.query.get(3)
print(defect_chk.CHECKLIST_NAME)

testcase_chk = ChecklistDetails.query.get(10)
print(testcase_chk.CHECKLIST_NAME)

## To get all data in the Table PRD_CHECKLIST_DETAILS
all_checklists = ChecklistDetails.query.all()
print(all_checklists)
print('-----------------------------------')
