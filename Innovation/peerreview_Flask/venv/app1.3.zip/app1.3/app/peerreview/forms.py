from flask_wtf import FlaskForm
from wtforms import StringField,PasswordField,SubmitField,BooleanField
from wtforms.validators import DataRequired,Length,Email,EqualTo

class LoginForm(FlaskForm):
    email = StringField('Email',validators=[DataRequired(),Email()])
    password = PasswordField('Password',validators=[DataRequired()])
    remember = BooleanField('Remember Me')
    submit = SubmitField('Login')

class AdminForm(FlaskForm):
    create_new_project = SubmitField('Create New Project')
    edit_project = SubmitField('Edit Existing Project')
    update_tracker = SubmitField('Update Tracker')

class CreateProjectForm(FlaskForm):
    project_name = StringField('Enter Project Name', validators=[DataRequired()])
    select_spoc = StringField('Select SPOC', validators=[DataRequired()])
    select_frequency = StringField('Select Frequency of Review', validators=[DataRequired()])
    submit = SubmitField('Submit')