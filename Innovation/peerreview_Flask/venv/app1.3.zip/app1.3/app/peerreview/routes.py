from flask import render_template,request,redirect,url_for,flash
from peerreview import app
from peerreview.forms import *
from peerreview.models import *
from flask_login import login_user,logout_user,current_user,login_required,login_manager

@app.route("/")
@app.route("/home",methods=['GET','POST'])
# @login_required
def home():
    return render_template('home.html',title='Home')


@app.route("/login",methods=['GET','POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    form = LoginForm()
    if form.validate_on_submit() :
       # print('login successful')
       # return redirect(url_for('home'))
       flash('Logged in Successfully!', 'success')
       user = EmployeeDetails.query.filter_by(LOGIN_USR_ID=form.email.data).first()
      # password = EmployeeDetails.query.filter_by(LOGIN_PASSWORD=form.password.data).first()
       if user and user.LOGIN_PASSWORD == form.password.data:
           #save login user details to Login_info table
           log=Login(LOGIN_NAME=user.EMP_NAME,LOGIN_USR_ID=user.LOGIN_USR_ID)
           db.session.add(log)
           db.session.commit()
           login_user(user)
           #flash('Logged in Successfully!', 'success')
           #login_info(user)
           #next_page = request.args.get('next')
           #print(next_page)
           #return redirect(url_for('admin'))
           if user.USR_LEVEL_ID == 1:
               print(user.USR_LEVEL_ID)
               return redirect(url_for('admin'))
           else:
               return redirect(url_for('user_page'))
       else:
            flash('login Unsuccessful. Please check the Email and Password entered', 'danger')
    else:
        flash('please use valid credentials','danger')
    return render_template('login.html',title='login' ,form = form)


#@app.route("/login",methods=['GET','POST'])
#def login():
#    if current_user.is_authenticated:
#        return redirect(url_for('home'))
#    form = LoginForm()
#    if form.validate_on_submit() :
       # print('login successful')
       # return redirect(url_for('home'))
#       user = EmployeeDetails.query.filter_by(LOGIN_USR_ID=form.email.data).first()
      # password = EmployeeDetails.query.filter_by(LOGIN_PASSWORD=form.password.data).first()
#       if user and user.LOGIN_PASSWORD == form.password.data:
           #save login user details to Login_info table
#           log=Login(LOGIN_NAME=user.EMP_NAME,LOGIN_USR_ID=user.LOGIN_USR_ID)
#           db.session.add(log)
#           login_user(user)
#           flash('Logged in Successfully!', 'success')
           #login_info(user)
           #next_page = request.args.get('next')
           #print(next_page)
           #return redirect(url_for('admin'))
#           return redirect(url_for('admin'))
#       else:
#            flash('login Unsuccessful. Please check the Email and Password entered', 'danger')
#    else:
#        flash('please use valid credentials','danger')
#    return render_template('login.html',title='login' ,form = form)

@app.route("/logout")
def logout():
    logout_user()
    return redirect(url_for('home'))

@app.route("/reset")
def reset():
    return render_template('reset.html', title='Reset')

@app.route("/admin", methods=['GET', 'POST'])
def admin():
    if request.method =='POST':
        return redirect(url_for('create_new_project'))
    return render_template('admin.html', title='Admin')

@app.route("/user_page")
def user_page():
    return render_template('user_page.html', title='User')

@app.route("/create_new_project",methods=['GET','POST'])
def create_new_project():
    if request.method == 'POST':

        PRJ_NAME = request.form['Projectname'],
        MANUAL_CHECKLIST = request.form.get('manual-chkbox'),
        MANUAL_DEFECT_CHECKLIST = request.form.get('manual-defect-chkbox'),
        MANUAL_TESTCASE_CHECKLIST = request.form.get('manual-testcase-chkbox'),
        MANUAL_TRACEABILITY_CHECKLIST = request.form.get('manual-reqtrace-chkbox'),
        AUTOMATION_CHECKLIST = request.form.get('auto-chkbox'),
        AUTO_STD_CHECKLIST = request.form.get('auto-autostd-chkbox'),
        AUTO_PYTHON_CHECKLIST = request.form.get('auto-python-chkbox'),
        AUTO_JAVA_CHECKLIST = request.form.get('auto-java-chkbox'),
        AUTO_C_CHECKLIST = request.form.get('auto-c#-chkbox'),
        AUTO_TOSCA_CHECKLIST = request.form.get('auto-tosca-chkbox'),
        AUTO_UFT_CHECKLIST = request.form.get('auto-uft-chkbox'),
        MANAGEMENT_CHECKLIST = request.form.get('mgmt-chkbox'),
        MGMT_TESTPLAN_CHECKLIST = request.form.get('mgmt-testplan-chkbox'),
        MGMT_TESTREPORT_CHECKLIST = request.form.get('mgmt-testreport-chkbox'),
        MGMT_TESTENVISETUP_CHECKLIST = request.form.get('mgmt-testenvtsetup-chkbox'),
        PERFORMANCE_CHECKLIST = request.form.get('performance-chkbox'),
        SECURITY_CHECKLIST = request.form.get('security-chkbox'),
        SPOC_ID = request.form['spoc'],
        REVIEWERS = request.form.getlist('lstBox2'),
        FREQUENCY_ID = request.form.get('frq-chkbox')

        Reviewers_list = list(REVIEWERS)
        flatlist = []
        for element in Reviewers_list:
            flatlist.extend(element)
        #print(flatlist)
        str1 = ';'.join(flatlist)
        #print(str1)


        new_project = CreateProject(PRJ_NAME=PRJ_NAME,MANUAL_CHECKLIST=MANUAL_CHECKLIST,MANUAL_DEFECT_CHECKLIST=MANUAL_DEFECT_CHECKLIST,MANUAL_TESTCASE_CHECKLIST=MANUAL_TESTCASE_CHECKLIST,
                                    MANUAL_TRACEABILITY_CHECKLIST=MANUAL_TRACEABILITY_CHECKLIST,AUTOMATION_CHECKLIST=AUTOMATION_CHECKLIST,AUTO_STD_CHECKLIST=AUTO_STD_CHECKLIST,
                                    AUTO_PYTHON_CHECKLIST=AUTO_PYTHON_CHECKLIST,AUTO_JAVA_CHECKLIST=AUTO_JAVA_CHECKLIST,AUTO_C_CHECKLIST=AUTO_C_CHECKLIST,
                                    AUTO_TOSCA_CHECKLIST=AUTO_TOSCA_CHECKLIST,AUTO_UFT_CHECKLIST=AUTO_UFT_CHECKLIST,MANAGEMENT_CHECKLIST=MANAGEMENT_CHECKLIST,
                                    MGMT_TESTPLAN_CHECKLIST=MGMT_TESTPLAN_CHECKLIST,MGMT_TESTREPORT_CHECKLIST=MGMT_TESTREPORT_CHECKLIST,MGMT_TESTENVISETUP_CHECKLIST=MGMT_TESTENVISETUP_CHECKLIST,
                                    PERFORMANCE_CHECKLIST=PERFORMANCE_CHECKLIST,SECURITY_CHECKLIST=SECURITY_CHECKLIST,SPOC_ID=SPOC_ID,REVIEWERS=str1,FREQUENCY_ID=FREQUENCY_ID)
        db.session.add(new_project)
        db.session.commit()

        project = CreateProject.query.all()
        print(project)

        return redirect(url_for('admin'))

    return render_template('create_new_project.html',title='create_new_project')

@app.route("/edit_existing_project",methods=['GET','POST'])
def edit_existing_project():
    return render_template('edit_existing_project.html')

@app.route("/update_tracker",methods=['GET','POST'])
def update_tracker():
    return render_template('update_tracker.html')
