from flask import render_template,request,redirect,url_for,flash
from peerreview import app
from peerreview.forms import LoginForm
from peerreview.models import EmployeeDetails
from flask_login import login_user,logout_user,current_user,login_required,login_manager
from werkzeug.security import generate_password_hash,check_password_hash

# Base page routing in case of multiple applications
# @app.route("/")
# @app.route("/index")
# def index():
#     return render_template('index.html',title='Index')

@app.route("/")
@app.route("/home")
@login_required  
def home():
    return render_template('home.html',title='Home') 

@app.route("/login",methods=['GET','POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    form = LoginForm()
    if form.validate_on_submit():
        user = EmployeeDetails.query.filter_by(LOGIN_USR_ID=form.email.data).first()
        if user and user.LOGIN_PASSWORD == form.password.data:
       #if user and check_password_hash(user.LOGIN_PASSWORD,form.password.data)   //After storing hashed password by code in Employee table
            login_user(user,remember=form.remember.data)
            flash('Logged in successfully!','success')
            login_info(user)
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('home'))   
        else:
            flash('Login Unsuccessful.Please check your Email and Password.','danger')
    return render_template('user_login.html',title='login' ,form = form)

@app.route("/logout")
@login_required 
def logout():
    logout_user()
    return redirect(url_for('login'))

def login_info(user):
    #save login user details to Login_info table
    print(user.EMP_NAME)    

@app.route("/create_new_project",methods=['GET','POST'])
@login_required 
def create_new_project():
    return render_template('create_new_project.html',title='create_new_project') 

@app.route("/edit_existing_project",methods=['GET','POST'])
@login_required 
def edit_existing_project():
    return render_template('edit_existing_project.html') 

@app.route("/update_tracker",methods=['GET','POST'])
@login_required 
def update_tracker():
    return render_template('update_tracker.html')         
